import org.springframework.mock.web.MockServletContext
import org.codehaus.groovy.grails.commons.spring.GrailsRuntimeConfigurator;
import org.springframework.core.io.Resource;
import org.codehaus.groovy.grails.commons.GrailsClassUtils
import java.lang.reflect.Method
import java.lang.reflect.Modifier
import org.apache.commons.io.FileUtils

Ant.property(environment:"env")

grailsHome = Ant.antProject.properties."env.GRAILS_HOME"

def srcDir = 'src/java'
GROOVY_METHODS = [
       'getMetaClass',
       'getProperty',
       'invokeMethod',
       'setMetaClass',
       'setProperty' ] as Set

Class COLLECTION_TYPE_ARG_CLASS
Class MAP_TYPE_ARG_CLASS

includeTargets << new File ("${grailsHome}/scripts/Init.groovy")
includeTargets << new File ( "${grailsHome}/scripts/Package.groovy" )

target ('default': 'Regenerates the service interface classes') {
    depends(checkVersion, packageApp)

    initJVMCheck()
    
     rootLoader.addURL(classesDir.toURL())
     def beans = new grails.spring.WebBeanBuilder().beans {
        resourceHolder(org.codehaus.groovy.grails.commons.spring.GrailsResourceHolder) {
            this.resources = "file:${basedir}/grails-app/**/*.groovy"
        }
        grailsResourceLoader(org.codehaus.groovy.grails.commons.GrailsResourceLoaderFactoryBean) {
            grailsResourceHolder = resourceHolder
        }
        def pluginResources = [] as Resource[]
        if(new File("${basedir}/plugins/*/plugin.xml").exists()) {
            pluginResources = "file:${basedir}/plugins/*/plugin.xml"
        }
        
        pluginMetaManager(org.codehaus.groovy.grails.plugins.DefaultPluginMetaManager, pluginResources)
        grailsApplication(org.codehaus.groovy.grails.commons.DefaultGrailsApplication.class, ref("grailsResourceLoader"))
    }

    
    appCtx = beans.createApplicationContext()
    appCtx.servletContext = new MockServletContext()
    grailsApp = appCtx.grailsApplication
    grailsApp.initialise()

    grailsApp.serviceClasses.each { serviceWrapper ->
        println "Checking service: " + serviceWrapper.shortName
        if (getPackage(serviceWrapper)) {
            println "Service is exposed to GWT"
            generateClientInterfaces(serviceWrapper, getPackage(serviceWrapper))
        } else {
            println "Service is not exposed to GWT"
        }
    }
}

def getPackage(serviceWrapper) {
    def exposeList = GrailsClassUtils.getStaticPropertyValue(serviceWrapper.clazz, 'expose')

    // Check whether 'gwt' is in the expose list.
    def gwtExposed = exposeList?.find { it.startsWith('gwt:') }
    if (gwtExposed) {
        def m = gwtExposed =~ 'gwt:(.*)'
        return m[0][1]
    }
    else {
        return null
    }
}

/**
 * Creates the required service and async interfaces for a given
 * Grails service. This checks to make sure that neither interface
 * file has been modified since they were last generated. If either
 * has, then the generation is skipped - we don't want to overwrite
 * user changes.
 * @param serviceWrapper (GrailsClass) The Grails service's class.
 * @param packageName (String) The GWT client package in which to
 * put the interfaces.
 */
def generateClientInterfaces(serviceWrapper, packageName) {
    // Find the directory in which to store the interface files.
    def outputDir = new File(srcDir, packageName.replace('.' as char, '/' as char))

    // Make sure that the output directory exists so that we can
    // create the interface files in it.
    if (!outputDir.exists()) {
        // The directory doesn't exist - it should really, since
        // a GWT module should reside here. Give the user the
        // benefit of the doubt and attempt to create the directory,
        // but log a warning in case the package is incorrect.
        println "Warn: " +  "Directory '${outputDir}' does not exist - creating it now."
        if (!outputDir.mkdirs()) {
            println "Error: " +  "Could not create required output directory."
            return
        }
    }
    
    // There should be a timestamp file indicating when the interface
    // files were last generated. Get hold of it.
    def className = serviceWrapper.shortName
    def timestampFile = new File(outputDir, "${className}.timestamp")

    // And the generated interface files.
    def mainFile = new File(outputDir, "${className}.java")
    def asyncFile = new File(outputDir, "${className}Async.java")

    // Now check that neither the main interface file, nor the
    // async one, has been modified since the last generation.
    if (timestampFile.exists()) {
        if (mainFile.exists() && asyncFile.exists() &&
                (mainFile.lastModified() > timestampFile.lastModified() ||
                 asyncFile.lastModified() > timestampFile.lastModified())) {
            // Either the main interface file, or the async file (or
            // both), has been modified since last generation, so skip
            // the generation this time around.
            println "Interface or async file changed manually. Not overwriting => Skipped"
            return
        }
    }
    else {
        // The timestamp doesn't exist, so the interfaces haven't
        // been generated yet. However, if the files exist already,
        // we should leave them alone.
        if (mainFile.exists() && asyncFile.exists()) {
            println "Timestamp file does not exist. Not overwriting existing interface classes => Skipped"
            return
        }
    }
    
    // Start the content of the main interface definition.
    def output = new StringBuffer("""\
package ${packageName};

import com.google.gwt.user.client.rpc.RemoteService;

public interface ${className} extends RemoteService {""")

    // Start the content of the async interface definition.
    def outputAsync = new StringBuffer("""\
package ${packageName};

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface ${className}Async {""")

    def excludedMethods = GrailsClassUtils.getStaticPropertyValue(serviceWrapper.clazz, 'gwtServiceExcludedMethods')
    
    // Iterate through the methods declared by the Grails service,
    // adding the appropriate ones to the interface definitions.
    serviceWrapper.clazz.declaredMethods.each { Method method ->
        // Skip non-public, static, and Groovy methods.
        if (!Modifier.isPublic(method.modifiers) ||
                Modifier.isStatic(method.modifiers) ||
                GROOVY_METHODS.contains(method.name) ||
                excludedMethods?.find { it.equals(method.name) }
            )  {
            return
        }

        // Handle any TypeArg annotations on this method and its
        // parameters.
        if (COLLECTION_TYPE_ARG_CLASS != null) {
            handleTypeArg(output, method)
        }
        output << "\n    // ${method.name}"
        // Output this method definition.
        output << "\n    ${getType(method.returnType)} ${method.name}("
        outputAsync << "\n    void ${method.name}("

        // Handle the method's parameters.
        def paramTypes = method.parameterTypes
        for (int i in 0..<paramTypes.size()) {
            if (i > 0) {
                output << ', '
                outputAsync << ', '
            }

            def paramString = "${getType(paramTypes[i])} arg${i}"
            output << paramString
            outputAsync << paramString
        }

        // Close the method off in the main interface definition.
        output << ');'

        // The async interface definition requires an extra parameter
        // on the method.
        if (paramTypes.size() > 0) {
            outputAsync << ', '
        }
        outputAsync << 'AsyncCallback callback);'
    }

    // Close the interface definitions off.
    output << '\n}\n'
    outputAsync << '\n}\n'

    // Write the definitions to the appropriate files.
    mainFile.write(output.toString())
    asyncFile.write(outputAsync.toString())

    // Now update/create the timestamp file so that we know when
    // these interface files were generated.
    FileUtils.touch(timestampFile)
    
    
    println "Interface file succesfully created: " + mainFile.absolutePath
    println "Async file succesfully created: " + asyncFile.absolutePath
    println "Timestamp file succesfully created: " + timestampFile.absolutePath
}

def initJVMCheck() {
//     Check whether the JVM supports annotations.
    try {
        // Try to load the Annotation class dynamically.
        Class.forName('java.lang.annotation.Annotation')

        // The Annotation class was loaded fine, so we can check
        // for the TypeArg annotation. We load the annotation
        // class dynamically so that the plugin can be used with
        // the 1.4 JDK.
        COLLECTION_TYPE_ARG_CLASS =
            Class.forName('org.codehaus.groovy.grails.plugins.gwt.annotation.CollectionTypeArg')
        MAP_TYPE_ARG_CLASS =
            Class.forName('org.codehaus.groovy.grails.plugins.gwt.annotation.MapTypeArg')
    }
    catch (ClassNotFoundException ex) {
        COLLECTION_TYPE_ARG_CLASS = null
        MAP_TYPE_ARG_CLASS = null
    }
}

/**
 * Returns the string representation of the given type. For example,
 * 'java.lang.String', 'int', 'java.lang.String[]', 'boolean[][][]'.
 */
def getType(clazz) {
    if (!clazz.array) {
        // If the type is not an array, we can simply return its
        // name.
        return clazz.name
    }
    else {
        // The class name contains some number of '[' characters
        // indicating the dimensions of the array.
        def dimensions = clazz.name.count('[')

        // To get the base type of the array, we have to recurse
        // through the component types.
        def type = clazz.componentType
        for (int i in 1..<dimensions) {
            type = type.componentType
        }

        return type.name + '[]' * dimensions
    }
}

/**
 * Checks for any TypeArg annotations on a given method and writes
 * the appropriate javadoc with '@gwt.typeArgs' tags if necessary.
 * @param output (output stream, string buffer) The stream or buffer
 * to write the javadoc to. The only requirement is that is supports
 * the '<<' operator.
 * @param method (Method) The method definition to process.
 */
def handleTypeArg(output, method) {
    // Determines whether we have started writing the javadoc
    // comment or not.
    def commentStarted = false

    // Handle the method's parameters.
    def paramAnns = method.parameterAnnotations
    def paramTypes = method.parameterTypes
    for (int i in 0..<paramAnns.size()) {
        if (paramAnns[i].size() > 0) {
            // Look for a TypeArg annotation on this parameter.
            paramAnns[i].each { ann ->
                if (COLLECTION_TYPE_ARG_CLASS.isInstance(ann) || MAP_TYPE_ARG_CLASS.isInstance(ann)) {
                    checkTypeArg(paramTypes[i], ann)

                    // Found it. So add a GWT typeArgs javadoc for
                    // it.
                    writeTypeArgEntry(output, ann, "arg$i")
                }
            }
        }
    }

    // Check for a TypeArg annotation on the method itself. This
    // will apply to the return type of the method.
    def ann = method.getAnnotation(COLLECTION_TYPE_ARG_CLASS)
    if (!ann) ann = method.getAnnotation(MAP_TYPE_ARG_CLASS)
    if (ann) {
        checkTypeArg(method.returnType, ann)
        if (!commentStarted) {
            startTypeArgComment(output)
            commentStarted = true
        }
        writeTypeArgEntry(output, ann, null)
    }

    // Close the javadoc comment if we started one.
    if (commentStarted) {
        endTypeArgComment(output)
    }
}

/**
 * Checks whether a TypeArg annotation matches the given type. If
 * it doesn't, an exception is thrown.
 * @param type (Class) The type to check the annotation against.
 * Should either implement Collection or Map.
 * @param ann (Annotation) The TypeArg annotation to check.
 */
def checkTypeArg(type, ann) {
    if (Collection.isAssignableFrom(type)) {
        if (!COLLECTION_TYPE_ARG_CLASS.isInstance(ann)) {
            throw new RuntimeException(
                    "TypeArg error: annotation is not of type CollectionTypeArg, " +
                    "but the corresponding type is a Collection.")
        }
    }
    else if (Map.isAssignableFrom(type)) {
        if (!MAP_TYPE_ARG_CLASS.isInstance(ann)) {
            throw new RuntimeException(
                    "TypeArg error: annotation is not of type MapTypeArg, " +
                    "but the corresponding type is a Map.")
        }
    }
    else {
        throw new RuntimeException(
                "TypeArg error: annotation present, but the corresponding type " +
                "is neither a Collection nor a Map.")
    }
}

/**
 * Writes the start of a javadoc comment to the given output.
 */
def startTypeArgComment(output) {
    output << '\n    /**'
}

/**
 * Writes the end of a javadoc comment to the given output.
 */
def endTypeArgComment(output) {
    output << '\n     */'
}

/**
 * Writes a '@gwt.typeArgs' javadoc entry for the given annotation
 * and parameter name.
 * @param output (stream, buffer) The output to write the entry to.
 * The only requirement is that it implements the '<<' operator.
 * @param ann (Annotation) The TypeArg annotation to generate the
 * GWT javadoc tag for.
 * @param paramName (String) The parameter name as specified in the
 * corresponding method signature. Use <code>null</code> if the tag
 * corresponds to a return type.
 */
def writeTypeArgEntry(output, ann, paramName) {
    output << '\n     * @gwt.typeArgs'
    if (paramName) {
        output << ' ' << paramName
    }
    output << ' <'
    if (MAP_TYPE_ARG_CLASS.isInstance(ann)) {
        output << ann.key().name << ', '
    }
    output << ann.value().name << '>'
}

/**
 * Searches a given directory for any GWT module files, and
 * returns a list of their fully-qualified names.
 * @param searchDir A string path specifying the directory
 * to search in.
 * @return a list of fully-qualified module names.
 */
def findModules(searchDir) {
    def modules = []
    def baseLength = searchDir.size()

    new File(searchDir).eachFileRecurse { file ->
        // Replace Windows separators with Unix ones.
        file = file.path.replace('\\' as char, '/' as char)

        // Chop off the search directory.
        file = file.substring(baseLength + 1)

        // Now check whether this path matches a module file.
        def m = file =~ /([\w\/]+)\.gwt\.xml$/
        if (m.count > 0) {
            // Extract the fully-qualified module name.
            modules << m[0][1].replace('/' as char, '.' as char)
        }
    }

    return modules
}
