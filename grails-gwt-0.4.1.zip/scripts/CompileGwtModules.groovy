includeTargets << new File("${gwtPluginDir}/scripts/_GwtInternal.groovy")

target (default: "Calls 'compileGetModules'.") {
    depends(parseArguments)

    // Force compilation of the GWT modules.
    gwtForceCompile = true

    // If arguments are provided, treat them as a list of modules to
    // compile.
    gwtModuleList = argsMap["params"]

    // Compile the GWT modules. This target is provided by '_GwtInternal'.
    compileGwtModules()
}
