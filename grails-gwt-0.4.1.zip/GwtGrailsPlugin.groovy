/*
 * Copyright 2007-2008 Peter Ledbrook.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.beans.Introspector
import java.beans.PropertyDescriptor
import java.lang.reflect.Method
import java.lang.reflect.Modifier
import org.apache.commons.io.FileUtils
import org.codehaus.groovy.grails.commons.GrailsClassUtils
import org.codehaus.groovy.grails.plugins.gwt.DefaultGwtServiceInterfaceGenerator
import org.codehaus.groovy.grails.web.plugins.support.WebMetaUtils
import org.codehaus.groovy.grails.plugins.gwt.GwtServiceInterfaceGenerator

class GwtGrailsPlugin {
    def version = "0.4.1"
    def grailsVersion = "1.1 > *"
    def author = "Peter Ledbrook"
    def authorEmail = "peter@cacoethes.co.uk"
    def title = "The Google Web Toolkit for Grails."
    def description = """\
Incorporates GWT into Grails. In particular, GWT host pages can be
GSPs and standard Grails services can be used to handle client RPC
requests.
"""
    def documentation = "http://www.grails.org/plugin/gwt"

    def observe = [ "services" ]

    def srcDir = "src/gwt"

    def doWithSpring = {
        gwtInterfaceGenerator(DefaultGwtServiceInterfaceGenerator)
    }   

    /**
     * Registers the common web-related dynamic properties on services
     * that are exposed via GWT.
     */
    def doWithDynamicMethods = { ctx ->
        def interfaceGenerator = ctx.getBean("gwtInterfaceGenerator")

        application.serviceClasses.each { serviceWrapper ->
            if (interfaceGenerator.isGwtExposed(serviceWrapper.clazz)) {
                WebMetaUtils.registerCommonWebProperties(serviceWrapper.clazz.metaClass, application)
            }
        }
    }

    /**
     * Registers the common web-related dynamic properties on services
     * that are reloaded and exposed via GWT.
     */
    def onChange = { event ->
        if (application.isServiceClass(event.source)) {
            def interfaceGenerator = event.ctx.getBean("gwtInterfaceGenerator")
            def serviceWrapper = application.getServiceClass(event.source?.name)

            if (interfaceGenerator.isGwtExposed(serviceWrapper.clazz)) {
                WebMetaUtils.registerCommonWebProperties(serviceWrapper.clazz.metaClass, application)
            }
        }
    }                                                                                  

    def onApplicationChange = { event ->
    }

    /**
     * Searches a given directory for any GWT module files, and
     * returns a list of their fully-qualified names.
     * @param searchDir A string path specifying the directory
     * to search in.
     * @return a list of fully-qualified module names.
     */
    def findModules(searchDir) {
        def modules = []
        def baseLength = searchDir.size()

        searchDir = new File(searchDir)
        if (!searchDir.exists()) return modules

        searchDir.eachFileRecurse { file ->
            // Replace Windows separators with Unix ones.
            file = file.path.replace('\\' as char, '/' as char)

            // Chop off the search directory.
            file = file.substring(baseLength + 1)

            // Now check whether this path matches a module file.
            def m = file =~ /([\w\/]+)\.gwt\.xml$/
            if (m.count > 0) {
                // Extract the fully-qualified module name.
                modules << m[0][1].replace('/' as char, '.' as char)
            }
        }

        return modules
    }
}
