@package.line@import @action.package@client.@action.name@Action
import @action.package@client.@action.name@Response

class @action.name@ActionHandler {
    @action.name@Response execute(@action.name@Action action) {
        return null
    }
}
