@action.package@class @action.name@ActionHandler {
    @action.name@Response execute(@action.name@Action action) {
        return null
    }
}
