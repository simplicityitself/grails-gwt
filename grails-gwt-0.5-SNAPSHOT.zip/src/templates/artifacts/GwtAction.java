package @action.package@client;

import org.grails.plugins.gwt.client.Action;

public class @action.name@Action implements Action<@action.name@Response> {
    private static final long serialVersionUID = 1L;

    public @action.name@Action() {
    }
}
