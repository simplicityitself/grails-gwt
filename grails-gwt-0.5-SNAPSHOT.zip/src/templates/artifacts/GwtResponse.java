package @action.package@client;

import org.grails.plugins.gwt.client.Response;

public class @action.name@Response implements Response {
    private static final long serialVersionUID = 1L;

    public @action.name@Response() {
    }
}
