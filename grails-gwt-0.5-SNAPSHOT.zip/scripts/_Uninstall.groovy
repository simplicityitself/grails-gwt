// Remove the directory for storing GWT files.
ant.delete(dir: "${basedir}/web-app/gwt")

